export const loggedIn = "Logged-In";
export const DECREMENT_COUNTER = "decrement-counter"; 
export const INCREMENT_COUNTER = "increment-counter";