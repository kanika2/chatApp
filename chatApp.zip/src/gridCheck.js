import React, { Component } from 'react';

export default class Boot extends Component {
    render() {
        return(
            <div className="container">
                <div className="row">
                    <div className="col-sm-4"> hello </div>
                    <div className="col-sm-4"> hello </div>
                    <div className="col-sm-4"> hello </div>
                </div>
            </div>
        );
    }
}