import React, {Component} from "react"

class Chat_app extends Component {
    
    render () {
        return(
            <p>yo</p>
        );
    }
}

export default Chat_app;